#!/bin/bash

if [ -z "$BASH_VERSION" ]; then
    echo "ERROR: This script requires Bash. Please run with Bash."
    exit 1
fi

# Valores por defecto
zip_folder="Zip_files"
takeout_folder="Takeout"
suffix="fixed"

# Flags por defecto
skip_log=false
skip_unzip=false
skip_gpth_tool=false
skip_exif_tool=false
skip_move_albums=false
flatten_all_photos_folder=false


# Funci�n para mostrar ayuda
usage() {
	echo ""
	echo "-------------------------------------------------------------------------------------------------------------------------------------------------------------"
	echo "OrganizeTakeoutPhotos v1.1"
	echo "Script (based on GPTH and EXIF Tools) to Process Google Takeout Photos (remove duplicates, fix metadata, organize per year/month folder, and separate Albums)"
	echo "by Jaime Tur (@jaimetur)"
	echo ""
    echo "Usage: $(basename "$0") [OPTIONS]"
    echo "Options:"
    echo "  -z,  --zip-folder                 Specify the Zip folder where the Zip files downloaded with Google Takeout are placed (default: Zip_files)"
    echo "  -t,  --takeout-folder             Specify the Takeout folder where all the Zip files downloaded with Google Takeout will be unpacked (default: Takeout)"
    echo "  -s,  --suffix                     Specify the suffix for the output folder. Output folder will be Takeout folder followed by _suffix (default: fixed)"
    echo ""
    echo "  -sl, --skip-log                   Flag to skip saving output messages into log file"
    echo "  -su, --skip-unzip                 Flag to skip unzip files"
    echo "  -sg, --skip-gpth-tool             Flag to skip process files with GPTH Tool"
    echo "  -se, --skip-exif-tool             Flag to skip process files with EXIF Tool"
    echo "  -sm, --skip-move-albums           Flag to skip move all albums into Albums folder"
    echo "  -fa, --flatten-all-photos-folder  Flag to skip create year/month folder structure on ALL_PHOTOS folder (Photos without album)"
    echo ""
    echo "  -h , --help                       Show this help message and exit"
   	echo "-------------------------------------------------------------------------------------------------------------------------------------------------------------"

}

# Parseo de argumentos
while [[ "$#" -gt 0 ]]; do
    case "$1" in
        -z|--zip-folder)
		    if [ -z "$2" ]; then
		        echo "ERROR: No folder specified for --zip-folder."
		        usage
		        exit 1
		    fi        
            zip_folder="${2%/}" # Quitamos barra (/) final si existe
            shift 2
            ;;
        -t|--takeout-folder)
		    if [ -z "$2" ]; then
		        echo "ERROR: No folder specified for --takeout-folder."
		        usage
		        exit 1
		    fi             
            takeout_folder="${2%/}" # Quitamos barra (/) final si existe
            shift 2
            ;;
        -s|--suffix)
            suffix="${2#_}" # Quitamos gui�n bajo (_) inicial si existe
            if [[ -z "$suffix" ]]; then
                echo "ERROR: Suffix cannot be empty."
                usage
                exit 1
            fi            
            shift 2
            ;;
        -sl|--skip-log)
            skip_log=true
            shift 1
            ;;	            
        -su|--skip-unzip)
            skip_unzip=true
        	shift 1
            ;; 
        -sg|--skip-gpth-tool)
            skip_gpth_tool=true
            shift 1
            ;;     
        -se|--skip-exif-tool)
		    skip_exif_tool=true
            shift 1
            ;;
        -sm|--skip-move-albums)
            skip_move_albums=true
            shift 1
            ;;		    
        -fa|--flatten-all-photos-folder)
            flatten_all_photos_folder=true
            shift 1
            ;;    		    
        -h|--help)
            usage
            exit 0
            ;;
        *)
            echo "Unknown option: $1"
            usage
            exit 1
            ;;
    esac
done

if ! $skip_log; then
	# Crear un archivo de log �nico con timestamp
	mkdir -p Logs
	timestamp=$(date +"%Y-%m-%d_%H-%M")
	log_file="Logs/log_process_$timestamp.txt"
	exec > >(tee -a "$log_file") 2>&1
fi

echo ""
echo "====================="
echo " STARTING PROCESS...."
echo "====================="
echo ""

# Inicia el temporizador
start_time=$(date +%s)

# Comprobar si las herramientas existen
if ! command -v ./gpth_tool/gpth &> /dev/null && ! skip_gpth_tool; then
    echo "WARNING: 'GPTH' tool not found. Setting 'skip_gpth_tool' flag to true."
    skip_gpth_tool=true
fi
if ! command -v ./exif_tool/exiftool &> /dev/null && ! skip_exif_tool; then
    echo "WARNING: 'EXIF' tool not found. Setting 'skip_exif_tool' flag to true."
    skip_exif_tool=true
fi

# Creamos las variables de las carpetas de salida
output_folder=${takeout_folder}_${suffix}
output_folder_no_albums=${output_folder}-no-albums

# Mensajes informativos
echo "INFO: Log file with all messages during the execution of this script is being saved into: $log_file"
echo ""
echo "INFO: Using Zip folder    : '$zip_folder'"
echo "INFO: Using Takeout folder: '$takeout_folder'"
echo "INFO: Using Suffix        : '$suffix'"
echo "INFO: Using Output folder : '$output_folder'"
echo ""
if $skip_log; then 
	echo "INFO: Flag detected '--skip-log'. Skipping saving output into log file..." 
fi
if $skip_unzip; then 
	echo "INFO: Flag detected '--skip-unzip'. Skipping Unzipping files..." 
fi
if $skip_gpth_tool; then 
	echo "INFO: Flag detected '--skip-gpth-toot'. Skipping Processing photos with GPTH Tool..." 
fi
if $skip_exif_tool;	then 
	echo "INFO: Flag detected '--skip-exif-tool'. Skipping Processing photos with EXIF Tool..." 
fi
if $skip_move_albums; then 
	echo "INFO: Flag detected '--skip-move-albums'. Skipping Moving Albums to Albums folder..." 
fi
if $flatten_all_photos_folder; then 
	echo "INFO: Flag detected '--flatten_all_photos_folder'. Skipping second pass of GPTH tool to organize ALL_PHOTOS folder with year/month structure..." 
fi


# Comienza la llamada a los diferentes scripts
if ! $skip_unzip; then
	echo ""
	echo "==============================="
	echo "1. UNPACKING TAKEOUT FOLDER..."
	echo "==============================="
	./1-unzip_all.sh $zip_folder $takeout_folder
fi

if ! $skip_gpth_tool; then
	echo ""
	echo "============================================"
	echo "2a. FIXING PHOTOS METADATA WITH GPTH TOOL..."
	echo "============================================"
	./2-fix_photos_with_gpth_tool.sh $takeout_folder $suffix
fi

if [[ ! $flatten_all_photos_folder && ! $skip_gpth_tool ]]; then
	echo ""
	echo "=========================================================================="
	echo "2b. FIXING ALL_PHOTOS FOLDER (WITH YEAR/MONTH STRUCTURE) WITH GPTH TOOL..."
	echo "=========================================================================="
	./2-fix_photos_with_gpth_tool.sh $takeout_folder $suffix "no-albums"
	rm -rf ./$output_folder/ALL_PHOTOS
	mv ./$output_folder_no_albums/ALL_PHOTOS ./$output_folder/ALL_PHOTOS
	rm -rf ./$output_folder_no_albums
fi
	
if ! $skip_move_albums; then
	echo ""
	echo "=========================="
	echo "3. MOVING ALBUMS FOLDER..."
	echo "=========================="
	./3-move_albums.sh $output_folder
fi

if ! $skip_exif_tool; then
	echo ""
	echo "==========================================="
	echo "4. FIXING PHOTOS METADATA WITH EXIF TOOL..."
	echo "==========================================="
	./4-fix_photos_with_exif_tool.sh $output_folder
fi

echo ""
echo "INFO: Process Completed with success!. All your photos should be fixed and organized now in the folder: '$output_folder'"
echo ""

# Variables para el Resumen final
files_unzipped=0
photos_videos_without_duplicates=0
photos_videos_without_album=0
photos_videos_within_album=0
total_albums=0

# Funci�n para contar archivos en una carpeta
count_files_in_folder() {
    local folder="$1"
    find "$folder" -type f | wc -l
}

# Conteo para el Resumen final
if [ -d "$takeout_folder" ]; then
	files_unzipped=$(count_files_in_folder "$takeout_folder")
fi
if [ -d "$output_folder" ]; then
	photos_videos_without_duplicates=$(count_files_in_folder "$output_folder")
	photos_videos_without_album=$(count_files_in_folder "$output_folder/ALL_PHOTOS")
	photos_videos_within_album=$(count_files_in_folder "$output_folder/Albums")
	total_albums=$(find "$output_folder/Albums" -mindepth 1 -type d | wc -l)
fi

echo ""
echo "=================================================="
echo "PROCESS COMPLETED SUMMARY:"
echo "=================================================="
echo ""
echo "INFO: Total files unpacked (including duplicates and metadata): $files_unzipped"
echo "INFO: Total photos/videos without duplicates: $photos_videos_without_duplicates"
echo "INFO: Total photos/videos without albums: $photos_videos_without_album"
echo "INFO: Total photos/videos within any album: $photos_videos_within_album"
echo "INFO: Total albums: $total_albums"
echo ""

# Finaliza el temporizador
end_time=$(date +%s)
# Calcula el tiempo total transcurrido
elapsed_time=$((end_time - start_time))
# Muestra el tiempo transcurrido en un formato legible
echo ""
echo "INFO: Total elapsed time: $((elapsed_time / 60)) minutes and $((elapsed_time % 60)) seconds."
echo ""

echo ""
echo "================================="
echo "PROCESS COMPLETED WITH SUCCESS!!!"
echo "================================="
echo ""
