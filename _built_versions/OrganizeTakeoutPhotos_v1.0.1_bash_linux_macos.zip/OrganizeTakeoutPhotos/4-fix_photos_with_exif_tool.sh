#!/bin/bash

if [ -z "$1" ]; then
    echo "ERROR: Please, introduce the input_folder as argument."
    exit 1
else
	./exif_tool/exiftool -overwrite_original -r -if 'not defined DateTimeOriginal' -P "-AllDates<FileModifyDate" "$1/"
fi
