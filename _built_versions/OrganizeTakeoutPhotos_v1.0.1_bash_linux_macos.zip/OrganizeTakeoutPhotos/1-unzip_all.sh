#!/bin/bash

if [ -z "$1" ]; then
	# Definición de carpeta por defecto
	input_zip_folder="Zip_files"
else
	input_zip_folder=$1
fi
if [ -z "$2" ]; then
	# Si no le pasamos la carpeta donde extraer los archivos, lo extraeremos en la carpeta donde se ejecuta el script
	extract_dir=$(pwd)
else
	extract_dir=$2
fi

output_zip_folder="${input_zip_folder}_processed"

echo ""
echo "INFO: Unpacking all Zip files in folder: '$input_zip_folder'"
echo "INFO: The extracted Zip files will be moved (if extraction is successful) to the folder: '$output_zip_folder'"
echo "INFO: The files will be extracted into the folder: '$extract_dir'"
echo ""

# Crea la carpeta de zip procesados si no existe
mkdir -p "$output_zip_folder"

# Comprueba si hay archivos ZIP en la carpeta de entrada
if ls "$input_zip_folder"/*.zip 1> /dev/null 2>&1; then
    # Itera sobre los archivos ZIP encontrados
    for file in "$input_zip_folder"/*.zip; do
        echo ""
        echo "INFO: Processing file: '$file'..."
        # Extrae el contenido del archivo ZIP directamente al directorio actual
        if 7z x "$file" -y -o"$extract_dir" -scsUTF-8; then
            echo ""
            echo "INFO: Successfully extracted '$file' to '$extract_dir'."
            # Mueve el archivo ZIP procesado a la carpeta de salida
            mv "$file" "$output_zip_folder/"
        else
        	echo ""
            echo "ERROR: Failed to extract '$file'. Skipping."
        fi
    done
    echo ""
    echo "INFO: All ZIP files have been processed and moved to folder: '$output_zip_folder'."
else
	echo ""
    echo "WARNING: No ZIP files found in folder: '$input_zip_folder'."
fi
