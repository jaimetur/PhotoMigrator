#!/bin/bash

if [ -z "$1" ]; then
    echo "ERROR: Please, introduce the takeout_folder as argument."
    exit 1
else
	takeout_folder=$1
	echo ""
	echo "INFO: Processing Takeout folder: '$takeout_folder'"
	#echo "INFO: Input arguments: '$@'"
	echo ""
	if [ -z "$2" ]; then
		suffix="fixed"
	else
		suffix="$2"
	fi
	if [ "$3" = "no-album" ] || [ "$3" = "no-albums" ] || [ "$3" = "no-albumes" ] || [ "$3" = "no-�lbum" ] || [ "$3" = "no-�lbums" ] || [ "$3" = "no-�lbumes" ]; then
		suffix="${suffix}-no-albums"
		mkdir -p ${takeout_folder}_${suffix}  # Crea la carpeta de salida a�adiendo el sufijo _fixed a la carpeta de entradaque le hemos pasado como argumento
		./gpth_tool/gpth --input $takeout_folder --output ${takeout_folder}_${suffix} --albums "nothing" --divide-to-dates --skip-extras --copy
	else
		mkdir -p $1_$suffix  # Crea la carpeta de salida a�adiendo el sufijo _fixed a la carpeta de entradaque le hemos pasado como argumento
		./gpth_tool/gpth --input $takeout_folder --output ${takeout_folder}_${suffix} --albums "duplicate-copy" --no-divide-to-dates --skip-extras --copy
		# ./gpth_tool/gpth --input $takeout_folder --output ${takeout_folder}_${suffix} --albums "shortcut" --no-divide-to-dates --skip-extras --copy
	fi
fi