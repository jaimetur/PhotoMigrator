#!/bin/bash

# Funci�n para contar archivos en una carpeta
function count_files_in_folder() {
    local folder="$1"
    find "$folder" -type f | wc -l
}

# Funci�n para descomprimir ficheros zip
function unpack_zips() {
	usage() {	
	    echo "INFO: Usage: unpack_zips -i|--input-folder <input-folder> [-o|--output-folder <output-folder>]"
	}	
    # Procesar par�metros de entrada
    local input_folder=""
    local output_folder=""

    while [[ "$#" -gt 0 ]]; do
        case "$1" in
	        -i|--input-folder)
            	if [ -z "$2" ]; then
			        echo "ERROR: No folder specified for --input-folder."
					usage
					return 1
		    	fi  
	            input_folder="$(realpath "$2")"  # Usa realpath para obtener la ruta absoluta
	            shift 2
	            ;;
	        -o|--output_folder)
            	if [ -z "$2" ]; then
			        echo "ERROR: No folder specified for --output_folder."
					usage
					return 1
		    	fi  
	            output_folder="$(realpath "$2")"  # Usa realpath para obtener la ruta absoluta
	            shift 2
	            ;;
	        *)
	            echo "ERROR: Unknown option: $1"
	            usage
	            return 1
	            ;;
        esac
    done

    # Validar carpeta de entrada obligatoria
    if [ -z "$input_folder" ]; then
        echo "ERROR: The parameter -i|--input_folder is required."
        return 1
    fi

    # Si no se especifica la carpeta de salida, usar el directorio actual
    if [ -z "$output_folder" ]; then
        output_folder=$(pwd)
    fi

    # Carpeta donde se mover�n los ZIP extra�dos correctamente
    local output_zip_folder="${input_folder}_extracted"

    echo ""
    echo "INFO: Unpacking all Zip files in folder: '$input_folder'"
    echo "INFO: The extracted Zip files will be moved (if extraction is successful) to the folder: '$output_zip_folder'"
    echo "INFO: The files will be extracted into the folder: '$output_folder'"
    echo ""

    # Comprobar si hay archivos ZIP en la carpeta de entrada
    if ls "$input_folder"/*.zip 1> /dev/null 2>&1; then
	    # Crear la carpeta de ZIP procesados si no existe
	    mkdir -p "$output_zip_folder"
        # Iterar sobre los archivos ZIP encontrados
        for file in "$input_folder"/*.zip; do
            echo ""
            echo "INFO: Processing file: '$file'..."
            # Extraer el contenido del archivo ZIP al directorio actual
            if 7z x "$file" -y -o"$output_folder" -scsUTF-8; then
                echo ""
                echo "INFO: Successfully extracted '$file' to '$output_folder'."
                # Mover el archivo ZIP procesado a la carpeta de salida
                mv "$file" "$output_zip_folder/"
                echo "INFO: The archive '$file' has been extracted and moved to folder: '$output_zip_folder' successfully."
            else
                echo ""
                echo "ERROR: Failed to extract '$file'. Skipping."
            fi
        done
        echo ""
        echo "INFO: All extracted ZIP files have been processed and moved to folder: '$output_zip_folder'."
    else
        echo ""
        echo "WARNING: No ZIP files found in folder: '$input_folder'."
    fi
}


# Funci�n paar mover todos los albumes a una carpeta espec�fica para albumes
function move_albums() {
	usage() {
    	echo "INFO: Usage: move_albums -i|--input-folder <input-folder> [-a|--albums-subfolder <albums-subfolder>]"
	}
    # Variables inicializadas
    local input_folder=""
    local albums_subfolder=""

    # Procesar argumentos
    while [[ "$#" -gt 0 ]]; do
        case "$1" in
            -i|--input-folder)
            	if [ -z "$2" ]; then
			        echo "ERROR: No folder specified for --input-folder."
					usage
					return 1
		    	fi  
                input_folder="$(realpath "$2")"  # Usa realpath para obtener la ruta absoluta
                shift 2
                ;;
            -a|--albums-subfolder)
            	if [ -z "$2" ]; then
			        echo "ERROR: No folder specified for --albums-subfolder."
					usage
					return 1
		    	fi  
                albums_subfolder=$input_folder/$(basename "$2")
                shift 2
                ;;
            *)
	            echo "ERROR: Unknown option: $1"
                usage
                return 1
                ;;
        esac
    done

    # Verificar que se haya proporcionado el par�metro obligatorio
    if [[ -z "$input_folder" ]]; then
        echo "ERROR: The parameter -i|--input-folder is required."
        usage
        return 1
    fi

    # Asignar un valor predeterminado a albums_subfolder si no se proporcion�
    if [[ -z "$albums_subfolder" ]]; then
        albums_subfolder="$input_folder/Albums"
    fi
    
	# Crea la subcarpeta Albums si no existe
	mkdir -p "$albums_subfolder"
	
	# Mueve todas las carpetas excepto ALL_PHOTOS y evita conflictos
	for folder in "$input_folder"/*; do
	    # Aseg�rate de que sea un directorio y no sea la carpeta ALL_PHOTOS o Albums
	    if [ -d "$folder" ] && [ "$(basename "$folder")" != "ALL_PHOTOS" ] && [ "$(basename "$folder")" != "Albums" ]; then
	        mv "$folder" "$albums_subfolder/" > /dev/null 2>&1
	        echo "INFO: Moving to '$(basename $albums_subfolder)' the album folder called: '$(basename "$folder")' "
	    fi
	done
	echo ""
	echo "INFO: Process completed. All Album's folders have been moved to '$(basename $albums_subfolder)'."
}


# Funci�n para aplanar todas las subcarpetas dentro de una carpeta dada
function flatten_subfolders() {
	usage() {	
	    echo "INFO: Usage: flatten_subfolders -i|--input-folder <folder> [-e|--exclude-folder <subfolder>]"
	}
    local input_folder=""
    local exclude_subfolder=""

    # Parsear argumentos
    while [[ $# -gt 0 ]]; do
        case $1 in
            -i|--input-folder)
            	if [ -z "$2" ]; then
			        echo "ERROR: No folder specified for --input-folder."
					usage
					return 1
		    	fi              
                input_folder="$2"
                shift 2
                ;;
            -e|--exclude-subfolder)
            	if [ -z "$2" ]; then
			        echo "ERROR: No folder specified for --exclude-subfolder."
					usage
					return 1
		    	fi                  
                exclude_subfolder="$2"
                shift 2
                ;;
            *)
	            echo "ERROR: Unknown option: $1"
                usage
                return 1
                ;;
        esac
    done

    # Convertir a rutas absolutas
    input_folder=$(realpath "$input_folder")
    if [[ -n "$exclude_subfolder" ]]; then
        exclude_subfolder=$(realpath "$input_folder/$exclude_subfolder")
    fi

    # Caso especial: si la carpeta base es ALL_PHOTOS
    if [[ "$(basename "$input_folder")" == "ALL_PHOTOS" ]]; then
        find "$input_folder" -mindepth 2 -type f 2>/dev/null | while read -r file; do
            mv "$file" "$input_folder/"
        done
        # Eliminar todas las subcarpetas vac�as (incluso las que contienen archivos ocultos)
        find "$input_folder" -mindepth 1 -type d | while read -r dir; do
            rm -rf "$dir"
        done

    # Procesar carpetas normales
    else
	    find "$input_folder" -mindepth 1 -type d 2>/dev/null | while read -r subdir; do
	        # Verificar si es la carpeta excluida o est� dentro de ella
	        if [[ -n "$exclude_subfolder" && "$subdir" == "$exclude_subfolder"* ]]; then
	            continue
	        fi
	        # Mover archivos al nivel ra�z de su subcarpeta actual
	        find "$subdir" -mindepth 1 -type f 2>/dev/null | while read -r file; do
	            mv "$file" "$subdir/"
	        done
	        # Eliminar todas las sub-subcarpetas vac�as dentro del directorio procesado
	        find "$subdir" -depth -type d -empty -exec rmdir {} \; 2>/dev/null
	    done
	fi
	
    # Mensaje de confirmaci�n
    if [[ -n "$exclude_subfolder" ]]; then    
        echo "INFO: The content of all albums inside: '$(basename $input_folder)' has been flattened within their own folder, excluding subfolder: '$(basename $exclude_subfolder)'."
    else
        echo "INFO: The content of all subfolders inside: '$(basename $input_folder)' has been flattened within their own flder."
    fi
}

