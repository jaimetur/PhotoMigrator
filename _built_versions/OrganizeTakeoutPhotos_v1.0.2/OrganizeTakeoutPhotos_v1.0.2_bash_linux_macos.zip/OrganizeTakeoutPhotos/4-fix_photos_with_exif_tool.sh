#!/bin/bash

if [ -z "$1" ]; then
    echo "ERROR: Please, introduce the input_folder as argument."
    exit 1
else
	echo "INFO: Scanning output folder: '$1' to fix EXIF data..."
	#./exif_tool/exiftool -overwrite_original -r -if 'not defined DateTimeOriginal' -P "-AllDates<FileModifyDate" "$1/"
	./exif_tool/exiftool -overwrite_original -ExtractEmbedded -r '-datetimeoriginal<filemodifydate' -if '(not $datetimeoriginal or ($datetimeoriginal eq "0000:00:00 00:00:00"))' "$1/"
fi
