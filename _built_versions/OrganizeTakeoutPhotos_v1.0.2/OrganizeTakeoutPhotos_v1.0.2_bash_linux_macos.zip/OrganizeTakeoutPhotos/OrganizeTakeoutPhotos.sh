#!/bin/bash

SCRIPT_VERSION="OrganizeTakeoutPhotos v1.0.2"
SCRIPT_DATE="2024-11-20"

# Limpiamos la pantalla
clear

# Valores por defecto
zip_folder="Zip_files"
takeout_folder="Takeout"
suffix="fixed"

# Flags por defecto
skip_log=false
skip_unzip=false
skip_gpth_tool=false
skip_exif_tool=false
skip_move_albums=false
flatten_all_photos_folder=false

# Funci�n para mostrar ayuda
usage() {
	echo ""
	echo "-----------------------------------------------------------------------------------------------------------------------------------------------------------------------"
	echo "$SCRIPT_VERSION - $SCRIPT_DATE"
	echo "Script (based on GPTH and EXIF Tools) to Process Google Takeout Photos (remove duplicates, fix metadata, organize per year/month folder, and separate Albums)"
	echo "(c) by Jaime Tur (@jaimetur)"
	echo ""
    echo "Usage: $(basename "$0") [Options]"
    echo "Options:"
    echo "  -z,  --zip-folder                 Specify the Zip folder where the Zip files downloaded with Google Takeout are placed (default: Zip_files)"
    echo "  -t,  --takeout-folder             Specify the Takeout folder where all the Zip files downloaded with Google Takeout will be unpacked (default: Takeout)"
    echo "  -s,  --suffix                     Specify the suffix for the output folder. Output folder will be Takeout folder followed by _{suffix}_{timestamp} (default: fixed)"
    echo ""
    echo "  -sl, --skip-log                   Flag to skip saving output messages into log file"
    echo "  -su, --skip-unzip                 Flag to skip unzip files"
    echo "  -sg, --skip-gpth-tool             Flag to skip process files with GPTH Tool"
    echo "  -se, --skip-exif-tool             Flag to skip process files with EXIF Tool"
    echo "  -sm, --skip-move-albums           Flag to skip move all albums into Albums folder"
    echo "  -fa, --flatten-all-photos-folder  Flag to skip create year/month folder structure on ALL_PHOTOS folder (Photos without album)"
    echo ""
    echo "  -h , --help                       Show this help message and exit"
	echo "---------------------------------------------------------------------------------------------------------------------------------------------------------------------"

}

# Parseo de argumentos
while [[ "$#" -gt 0 ]]; do
    case "$1" in
        -z|--zip-folder)
		    if [ -z "$2" ]; then
		        echo "ERROR: No folder specified for --zip-folder."
		        usage
		        exit 1
		    fi        
            zip_folder="${2%/}" # Quitamos barra (/) final si existe
            shift 2
            ;;
        -t|--takeout-folder)
		    if [ -z "$2" ]; then
		        echo "ERROR: No folder specified for --takeout-folder."
		        usage
		        exit 1
		    fi             
            takeout_folder="${2%/}" # Quitamos barra (/) final si existe
            shift 2
            ;;
        -s|--suffix)
            suffix="${2#_}" # Quitamos gui�n bajo (_) inicial si existe
            if [[ -z "$suffix" ]]; then
                echo "ERROR: Suffix cannot be empty."
                usage
                exit 1
            fi            
            shift 2
            ;;
        -sl|--skip-log)
            skip_log=true
            shift 1
            ;;	            
        -su|--skip-unzip)
            skip_unzip=true
        	shift 1
            ;; 
        -sg|--skip-gpth-tool)
            skip_gpth_tool=true
            shift 1
            ;;     
        -se|--skip-exif-tool)
		    skip_exif_tool=true
            shift 1
            ;;
        -sm|--skip-move-albums)
            skip_move_albums=true
            shift 1
            ;;		    
        -fa|--flatten-all-photos-folder)
            flatten_all_photos_folder=true
            shift 1
            ;;    		    
        -h|--help)
            usage
            exit 0
            ;;
        *)
            echo "Unknown option: $1"
            usage
            exit 1
            ;;
    esac
done

if ! $skip_log; then
	# Crear un archivo de log �nico con timestamp
	mkdir -p Logs
	timestamp=$(date +"%Y%m%d-%H%M%S")
	log_file="Logs/log_process_$timestamp.txt"
	exec > >(tee -a "$log_file") 2>&1
fi
echo ""
echo "Running Script: $SCRIPT_VERSION - $SCRIPT_DATE"
if [ -n "$BASH_VERSION" ]; then
    echo "Script running on bash: $BASH_VERSION"
else
    echo "ERROR: This script requires Bash. Please run with Bash."
    exit 1
fi

echo ""
echo "====================="
echo " STARTING PROCESS...."
echo "====================="
echo ""
# A�adimos el timestamp al sufijo para identificar bien de qu� ejecuci�n es la carpeta de salida
suffix2=${suffix}_${timestamp}

# Inicia el temporizador
start_time=$(date +%s)

# Comprobar si las herramientas existen
if ! command -v ./gpth_tool/gpth &> /dev/null && ! skip_gpth_tool; then
    echo "WARNING: 'GPTH' tool not found. Setting 'skip_gpth_tool' flag to true."
    skip_gpth_tool=true
fi
if ! command -v ./exif_tool/exiftool &> /dev/null && ! skip_exif_tool; then
    echo "WARNING: 'EXIF' tool not found. Setting 'skip_exif_tool' flag to true."
    skip_exif_tool=true
fi

# Creamos las variables de las carpetas de salida
output_folder=${takeout_folder}_${suffix2}
output_folder_no_albums=${output_folder}-no-albums

# Mensajes informativos
echo "INFO: Log file with all messages during the execution of this script is being saved into file: $log_file"
echo ""
echo "INFO: Using Zip folder    : '$zip_folder'"
echo "INFO: Using Takeout folder: '$takeout_folder'"
echo "INFO: Using Suffix        : '$suffix'"
echo "INFO: Using Output folder : '$output_folder'"
echo ""
if $skip_log; then 
	echo "INFO: Flag detected '--skip-log'. Skipping saving output into log file..." 
fi
if $skip_unzip; then 
	echo "INFO: Flag detected '--skip-unzip'. Skipping Unzipping files..." 
fi
if $skip_gpth_tool; then 
	echo "INFO: Flag detected '--skip-gpth-toot'. Skipping Processing photos with GPTH Tool..." 
	echo "                                        Skipping Moving Albums to Albums folder..."
fi
if $skip_exif_tool;	then 
	echo "INFO: Flag detected '--skip-exif-tool'. Skipping Processing photos with EXIF Tool..." 
fi
if $skip_move_albums; then 
	echo "INFO: Flag detected '--skip-move-albums'. Skipping Moving Albums to Albums folder..." 
fi
if $flatten_all_photos_folder; then 
	echo "INFO: Flag detected '--flatten_all_photos_folder'. Skipping second pass of GPTH tool to organize ALL_PHOTOS folder with year/month structure..." 
fi
echo ""

# Comienza la llamada a los diferentes scripts

if ! $skip_unzip; then
	echo ""
	echo "==============================="
	echo "1. UNPACKING TAKEOUT FOLDER..."
	echo "==============================="
	echo""
	./1-unzip_all.sh $zip_folder $takeout_folder
else
	echo ""
	echo "==============================="
	echo "1. UNPACKING TAKEOUT FOLDER..."
	echo "==============================="
	echo""
	echo "INFO: Step skipped due to Flag detection: '--skip-unzip'"
	echo""
fi

if ! $skip_gpth_tool; then
	echo ""
	echo "============================================================================"
	echo "2a. FIXING PHOTOS METADATA WITH GPTH TOOL AND COPYING IT TO OUTPUT FOLDER..."
	echo "============================================================================"
	echo ""
	./2-fix_photos_with_gpth_tool.sh $takeout_folder $output_folder
else
	echo ""
	echo "============================================================================"
	echo "2a. FIXING PHOTOS METADATA WITH GPTH TOOL AND COPYING IT TO OUTPUT FOLDER..."
	echo "============================================================================"
	echo ""
	echo "INFO: Since Flag '--skip-gpth-toot' have been detected, we are now manually copying files to output folder: '$output_folder'..."
	echo ""
	# Detecta el directorio principal de la carpeta de entrada (aquel del que cuelgan todas las subcarpetas), y copia todas las subcarpetas a la carpeta destino en un mismo nivel excepto las carpetas que comiencen por 'Photos from dddd' y ALL_PHOTOS que se copiaran en una subcarpeta llamada ALL_PHOTOS en la carpeta de destino.
	DIRECTORIO_ORIGEN=$takeout_folder; 
	DIRECTORIO_DESTINO=$output_folder; 
	DIRECTORIO_ACTUAL="$DIRECTORIO_ORIGEN";
	while true; do NUM_DIRS=$(find "$DIRECTORIO_ACTUAL" -mindepth 1 -maxdepth 1 -type d | wc -l); NUM_FILES=$(find "$DIRECTORIO_ACTUAL" -mindepth 1 -maxdepth 1 -type f | wc -l); if [ "$NUM_DIRS" -eq 1 ] && [ "$NUM_FILES" -eq 0 ]; then DIRECTORIO_ACTUAL=$(find "$DIRECTORIO_ACTUAL" -mindepth 1 -maxdepth 1 -type d); else break; fi; done; mkdir -p "$DIRECTORIO_DESTINO/ALL_PHOTOS"; for dir in "$DIRECTORIO_ACTUAL"/Photos\ from\ [1-2][0-9][0-9][0-9]; do if [ -d "$dir" ]; then cp -r "$dir" "$DIRECTORIO_DESTINO/ALL_PHOTOS/"; fi; done; if [ -d "$DIRECTORIO_ACTUAL/ALL_PHOTOS" ]; then cp -r "$DIRECTORIO_ACTUAL/ALL_PHOTOS/"* "$DIRECTORIO_DESTINO/ALL_PHOTOS/"; fi; for dir in "$DIRECTORIO_ACTUAL"/*; do if [ -d "$dir" ] && [[ ! "$dir" =~ Photos\ from\ [1-2][0-9][0-9][0-9] ]] && [ "$(basename "$dir")" != "ALL_PHOTOS" ]; then cp -r "$dir" "$DIRECTORIO_DESTINO/"; fi; done
fi

if [ "$flatten_all_photos_folder" = false ] && [ "$skip_gpth_tool" = false ]; then
	echo ""
	echo "=========================================================================="
	echo "2b. FIXING ALL_PHOTOS FOLDER (WITH YEAR/MONTH STRUCTURE) WITH GPTH TOOL..."
	echo "=========================================================================="
	echo ""
	./2-fix_photos_with_gpth_tool.sh $takeout_folder $output_folder "no-albums"
	rm -rf ./$output_folder/ALL_PHOTOS
	mv ./$output_folder_no_albums/ALL_PHOTOS ./$output_folder/ALL_PHOTOS > /dev/null 2>&1
	rm -rf ./$output_folder_no_albums
else
	echo ""
	echo "=========================================================================="
	echo "2b. FIXING ALL_PHOTOS FOLDER (WITH YEAR/MONTH STRUCTURE) WITH GPTH TOOL..."
	echo "=========================================================================="
	echo ""
	echo "INFO: Step skipped due to Flag detection: '--flatten_all_photos_folder' or '--skip_gpth_tool'"
	echo ""	
fi

if ! $skip_move_albums; then
	echo ""
	echo "=========================="
	echo "3. MOVING ALBUMS FOLDER..."
	echo "=========================="
	echo ""	
	./3-move_albums.sh $output_folder
else
	echo ""
	echo "=========================="
	echo "3. MOVING ALBUMS FOLDER..."
	echo "=========================="
	echo ""	
	echo "INFO: Step skipped due to Flag detection: '--skip_move_albums'"
	echo""	
fi

if ! $skip_exif_tool; then
	echo ""
	echo "==========================================="
	echo "4. FIXING PHOTOS METADATA WITH EXIF TOOL..."
	echo "==========================================="
	echo""	
	./4-fix_photos_with_exif_tool.sh $output_folder
else
	echo ""
	echo "==========================================="
	echo "4. FIXING PHOTOS METADATA WITH EXIF TOOL..."
	echo "==========================================="
	echo""
	echo "INFO: Step skipped due to Flag detection: '--skip_exif_tool'"
	echo""
fi

echo ""
echo "INFO: Process Completed with success!. All your photos should be fixed and organized now in the folder: '$output_folder'"
echo ""

# Variables para el Resumen final
files_unzipped=0
photos_videos_without_duplicates=0
photos_videos_without_album=0
photos_videos_within_album=0
total_albums=0

# Funci�n para contar archivos en una carpeta
count_files_in_folder() {
    local folder="$1"
    find "$folder" -type f | wc -l
}

# Conteo para el Resumen final
if [ -d "$takeout_folder" ]; then
	files_unzipped=$(count_files_in_folder "$takeout_folder")
fi
if [ -d "$output_folder" ]; then
	photos_videos_without_duplicates=$(count_files_in_folder "$output_folder")
	photos_videos_without_album=$(count_files_in_folder "$output_folder/ALL_PHOTOS")
	photos_videos_within_album=$(count_files_in_folder "$output_folder/Albums")
	total_albums=$(find "$output_folder/Albums" -mindepth 1 -type d | wc -l)	
fi

echo ""
echo "=================================================="
echo "PROCESS COMPLETED SUMMARY:"
echo "=================================================="
echo ""
echo "INFO: Total files unpacked (including duplicates and metadata): $files_unzipped"
echo "INFO: Total photos/videos (without duplicates if GPTH tool was executed): $photos_videos_without_duplicates"
echo "INFO: Total photos/videos without albums: $photos_videos_without_album"
echo "INFO: Total photos/videos within any album: $photos_videos_within_album"
echo "INFO: Total albums: $total_albums"
echo ""

# Finaliza el temporizador
end_time=$(date +%s)
# Calcula el tiempo total transcurrido
elapsed_time=$((end_time - start_time))
# Muestra el tiempo transcurrido en un formato legible
echo ""
echo "INFO: Total elapsed time: $((elapsed_time / 60)) minutes and $((elapsed_time % 60)) seconds."
echo ""

echo "INFO: Log file with all messages during the execution of this script has been saved saved into file: $log_file"

echo ""
echo "================================="
echo "PROCESS COMPLETED WITH SUCCESS!!!"
echo "================================="
echo ""
