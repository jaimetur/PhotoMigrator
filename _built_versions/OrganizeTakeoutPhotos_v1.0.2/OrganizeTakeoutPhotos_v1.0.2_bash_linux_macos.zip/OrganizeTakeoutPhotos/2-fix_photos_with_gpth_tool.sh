#!/bin/bash

if [ -z "$1" ]; then
    echo "ERROR: Please, introduce the takeout_folder as argument."
    exit 1
else
	takeout_folder=$1
	echo ""
	echo "INFO: Processing Takeout folder: '$takeout_folder'"
	echo ""
	
	if [ -z "$2" ]; then # Si no le hemos pasado la carpeta de salida, la construiremos con el nombre de la carpeta de entrada seguida del sufijo "_fixed"
		output_folder=${takeout_folder}_"fixed"
	else
		output_folder="$2"
	fi
	
	if [ "$3" = "no-album" ] || [ "$3" = "no-albums" ] || [ "$3" = "no-albumes" ] || [ "$3" = "no-�lbum" ] || [ "$3" = "no-�lbums" ] || [ "$3" = "no-�lbumes" ]; then
		output_folder="${output_folder}-no-albums"
		mkdir -p ${output_folder}  # Crea la carpeta de salida en caso de que no exista
		./gpth_tool/gpth --input $takeout_folder --output ${output_folder} --albums "nothing" --divide-to-dates --skip-extras --copy
	else
		mkdir -p ${output_folder}  # Crea la carpeta de salida en caso de que no exista
		./gpth_tool/gpth --input $takeout_folder --output ${output_folder} --albums "duplicate-copy" --no-divide-to-dates --skip-extras --copy
		# ./gpth_tool/gpth --input $takeout_folder --output ${output_folder} --albums "shortcut" --no-divide-to-dates --skip-extras --copy
	fi
fi