#!/bin/bash

if [ -z "$1" ]; then
	# Definición de carpeta por defecto
	input_zip_folder="Takeout_zip_files"
else
	input_zip_folder=$1
fi
if [ -z "$2" ]; then
	# Si no le pasamos la carpeta donde extraer los archivos, lo extraeremos en la carpeta donde se ejecuta el script
	extract_dir="Takeout"
else
	extract_dir=$2
fi

output_zip_folder="${input_zip_folder}_processed"

echo ""
echo "INFO: Unpacking all Zip files in folder: '$input_zip_folder'"
echo "INFO: The extracted Zip files will be moved (if extraction is successful) to the folder: '$output_zip_folder'"
echo "INFO: The files will be extracted into the folder: '$extract_dir'"
echo ""

# Crea la carpeta de zip procesados si no existe
mkdir -p "$output_zip_folder"

# Crear la carpeta principal "Takeout"
main_dir=$extract_dir
mkdir -p "$main_dir"

# Comprueba si hay archivos ZIP en la carpeta de entrada
if ls "$input_zip_folder"/*.zip 1> /dev/null 2>&1; then
    # Itera sobre los archivos ZIP encontrados
    for file in "$input_zip_folder"/*.zip; do
        echo ""
        echo "INFO: Processing file: '$file'..."
        # Extraer el nombre base del archivo ZIP (sin la ruta y sin la extensión)
        base_name=$(basename "$file" .zip)
        # Crear una subcarpeta dentro de "Takeout" con el nombre del archivo ZIP
        output_dir="$main_dir/$base_name"
        mkdir -p "$output_dir"
        if 7z x "$file" -y -o"$output_dir" -scsUTF-8; then
            echo ""
            echo "INFO: Successfully extracted '$file' to '$current_dir'."
            # Mueve el archivo ZIP procesado a la carpeta de salida
            mv "$file" "$output_zip_folder/"
        else
        	echo ""
            echo "ERROR: Failed to extract '$file'. Skipping."
        fi
    done
    echo ""
    echo "INFO: All ZIP files have been processed and moved to folder: '$output_zip_folder'."
else
	echo ""
    echo "WARNING: No ZIP files found in folder: '$input_zip_folder'."
fi