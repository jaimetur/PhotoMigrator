#!/bin/bash

# Valores por defecto
zip_folder="Takeout_zip_files"
takeout_folder="Takeout"
suffix="fixed"

# Funci�n para mostrar ayuda
usage() {
	echo ""
	echo "-------------------------------------------------------------------------------------------------------------------------------------------------------------"
	echo "OrganizeTakeoutPhotos v1.0"
	echo "Script (based on GPTH and EXIF Tools) to Process Google Takeout Photos (remove duplicates, fix metadata, organize per year/month folder, and separate Albums)"
	echo "by Jaime Tur (@jaimetur)"
	echo ""
    echo "Usage: $0 [OPTIONS]"
    echo "Options:"
    echo "  -z, --zip-folder      Specify the Zip folder where the Zip files downloaded with Google Takeout are placed (default: Takeout_zip_files)"
    echo "  -t, --takeout-folder  Specify the Takeout folder where all the Zip files downloaded with Google Takeout will be unpacked (default: Takeout)"
    echo "  -s, --suffix          Specify the suffix for the output folder. Output folder will be Takeout folder followed by _suffix (default: fixed)"
    echo "  -h, --help            Show this help message and exit"
   	echo "-------------------------------------------------------------------------------------------------------------------------------------------------------------"

}

# Parseo de argumentos
while [[ "$#" -gt 0 ]]; do
    case "$1" in
        -z|--zip-folder)
            zip_folder="${2%/}" # Quitamos barra (/) final si existe
            shift 2
            ;;
        -t|--takeout-folder)
            takeout_folder="${2%/}" # Quitamos barra (/) final si existe
            shift 2
            ;;
        -s|--suffix)
            suffix="${2#_}" # Quitamos gui�n bajo (_) inicial si existe
            shift 2
            ;;
        -h|--help)
            usage
            exit 0
            ;;
        *)
            echo "Unknown option: $1"
            usage
            exit 1
            ;;
    esac
done

# Crear un archivo de log �nico con timestamp
timestamp=$(date +"%Y-%m-%d_%H-%M")
log_file="log_process_$timestamp.txt"
exec > >(tee -a "$log_file") 2>&1

echo ""
echo "====================="
echo " STARTING PROCESS...."
echo "====================="
echo ""

# Creamos las variables de las carpetas de salida
output_folder=${takeout_folder}_${suffix}
output_folder_no_albums=${output_folder}-no-albums

# Mensajes informativos
echo "INFO: Using Zip folder: '$zip_folder'"
echo "INFO: Using Takeout folder: '$takeout_folder'"
echo "INFO: Using Suffix: '$suffix'"
echo "INFO: Using Output folder: '$output_folder'"
echo ""

# Comienza la llamada a los diferentes scripts
echo ""
echo "==============================="
echo "1. UNPACKING TAKEOUT FOLDER..."
echo "==============================="
./1a-unzip_all_together.sh $zip_folder $takeout_folder
#./1b-unzip_per_file.sh $zip_folder


echo ""
echo "==========================================="
echo "2. FIXING PHOTOS METADATA WITH GPTH TOOL..."
echo "==========================================="
./2-fix_photos_with_gpth_tool.sh $takeout_folder $suffix
./2-fix_photos_with_gpth_tool.sh $takeout_folder $suffix "no-albums"

echo ""
echo "=========================="
echo "3. MOVING ALBUMS FOLDER..."
echo "=========================="
rm -rf ./$output_folder/ALL_PHOTOS
mv ./$output_folder_no_albums/ALL_PHOTOS ./$output_folder/ALL_PHOTOS
rm -rf ./$output_folder_no_albums
./3-move_albums.sh $output_folder

echo ""
echo "==========================================="
echo "4. FIXING PHOTOS METADATA WITH EXIF TOOL..."
echo "==========================================="
./4-fix_photos_with_exif_tool.sh $output_folder

echo ""
echo "================================="
echo "PROCESS COMPLETED WITH SUCCESS!!!"
echo "================================="
echo ""
