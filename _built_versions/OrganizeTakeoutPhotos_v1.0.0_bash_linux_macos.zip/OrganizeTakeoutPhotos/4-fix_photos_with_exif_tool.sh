#!/bin/bash

if [ -z "$1" ]; then
    echo "ERROR: Please, introduce the input_folder as argumento."
    exit 1
else
	./Image-ExifTool-13.03/exiftool -overwrite_original -r -if 'not defined DateTimeOriginal' -P "-AllDates<FileModifyDate" "$1/"
fi
