#!/bin/bash

echo ""
# Verifica que se haya pasado un argumento
if [ -z "$1" ]; then
    echo "ERROR: Please, introduce the input_folder as argumento."
    exit 1
fi

echo ""
echo "Moving to Albums..."

# Ruta de la carpeta dada como argumento
base_dir="$(realpath "$1")"  # Usa realpath para obtener la ruta absoluta

# Verifica que la carpeta dada exista
if [ ! -d "$base_dir" ]; then
    echo "The folder '$base_dir' does not exist."
    exit 1
fi

# Crea la subcarpeta Albums si no existe
albums_dir="$base_dir/Albums"
mkdir -p "$albums_dir"

# Mueve todas las carpetas excepto ALL_PHOTOS y evita conflictos
for dir in "$base_dir"/*; do
    # Aseg�rate de que sea un directorio y no sea la carpeta ALL_PHOTOS o Albums
    if [ -d "$dir" ] && [ "$(basename "$dir")" != "ALL_PHOTOS" ] && [ "$(basename "$dir")" != "Albums" ]; then
        mv "$dir" "$albums_dir/"
        echo "INFO: Moving '$(basename "$dir")' to 'Albums'"
    fi
done
echo ""
echo "INFO: Process completed. All folders (except ALL_PHOTOS) have been moved to '$albums_dir'."
