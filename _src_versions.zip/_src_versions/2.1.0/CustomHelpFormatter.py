import textwrap
import argparse
import re

class CustomHelpFormatter(argparse.RawDescriptionHelpFormatter):
    def __init__(self, *args, **kwargs):
        # Configura la anchura máxima del texto de ayuda
        kwargs['width'] = 110  # Ancho total del texto de ayuda
        kwargs['max_help_position'] = 55  # Ajusta la posición de inicio de las descripciones
        super().__init__(*args, **kwargs)

    def _tokenize_usage(self, usage_text):
        # 1) Sustituimos saltos de línea por espacio (para no partir el texto en varias líneas).
        flattened = usage_text.replace('\n', ' ')
        def parse_brackets(s):
            tokens = []
            i = 0
            n = len(s)
            while i < n:
                # Saltamos espacios iniciales
                if s[i].isspace():
                    i += 1
                    continue
                # Si encontramos un '[' => parseamos el contenido (anidado) hasta el corchete de cierre emparejado
                if s[i] == '[':
                    start = i
                    bracket_count = 1  # hemos encontrado un '['
                    i += 1
                    # Avanzamos hasta cerrar todos los corchetes '[' pendientes
                    while i < n and bracket_count > 0:
                        if s[i] == '[':
                            bracket_count += 1
                        elif s[i] == ']':
                            bracket_count -= 1
                        i += 1
                    # i está ahora justo detrás del corchete de cierre
                    tokens.append(s[start:i])  # incluimos el bloque completo con sus corchetes
                else:
                    # Caso: token "normal" (no empieza por '[')
                    start = i
                    # Avanzamos hasta encontrar un espacio o un '['
                    while i < n and not s[i].isspace() and s[i] != '[':
                        i += 1
                    tokens.append(s[start:i])
            return tokens
        tokens = parse_brackets(flattened)
        # Devolvemos como una sola "línea" con indent vacío
        return [('', tokens)]

    def _build_lines_with_forced_tokens(
        self,
        tokenized_usage,
        forced_tokens,
        width,
        first_line_indent = '',
        subsequent_indent = ' ' * 32
    ):
        final_lines = []
        for (orig_indent, tokens) in tokenized_usage:
            if not tokens:
                final_lines.append(orig_indent)
                continue

            current_line = first_line_indent
            current_len  = len(first_line_indent)
            first_token  = True
            line_number  = 0
            for token in tokens:
                match_forced = next((forced_token for forced_token in forced_tokens if token.startswith(forced_token)), None)
                if match_forced is not None:
                    must_be_alone = forced_tokens[match_forced]
                    # Forzamos salto de línea antes (si no estamos al inicio)
                    if not first_token:
                        final_lines.append(current_line)
                        current_line = subsequent_indent
                        current_len  = len(subsequent_indent)
                        first_token  = True
                        line_number += 1
                    if must_be_alone:
                        # Va solo en su línea
                        forced_line = (subsequent_indent if line_number > 0 else first_line_indent) + token
                        final_lines.append(forced_line)
                        current_line = subsequent_indent
                        current_len  = len(subsequent_indent)
                        first_token  = True
                        line_number += 1
                        continue
                # Lógica normal de añadir token
                if first_token:
                    current_line += token
                    current_len += len(token)
                    first_token = False
                else:
                    needed_len = current_len + 1 + len(token)
                    if needed_len > width:
                        final_lines.append(current_line)
                        line_number += 1
                        current_line = subsequent_indent + token
                        current_len  = len(subsequent_indent) + len(token)
                        first_token  = False
                    else:
                        current_line += ' ' + token
                        current_len = needed_len
            # Al acabar los tokens, si la línea no está vacía, la agregamos
            if current_line.strip():
                final_lines.append(current_line)
                line_number += 1
        return '\n'.join(final_lines)

    def _format_usage(self, usage, actions, groups, prefix, **kwargs):
        def remove_chain(usage, chain_to_remove):
            # 1) Unir todas las líneas (sustituir saltos de línea por espacio)
            usage_single_line = usage.replace('\n', ' ')
            # 2) Reemplazar 2 o más espacios consecutivos por uno solo
            usage_single_line = re.sub(r' {2,}', ' ', usage_single_line)
            # 3) Remover 'chain_to_remove'
            usage_single_line = usage_single_line.replace(chain_to_remove, '')
            return usage_single_line

        # 1) Uso básico de la clase padre
        usage = super()._format_usage(usage, actions, groups, prefix)

        # 2) Eliminamos el bloque con <DUPLICATES_ACTION> ...
        usage = remove_chain(usage, "[['list', 'move', 'remove'] <DUPLICATES_FOLDER> [<DUPLICATES_FOLDER> ...] ...]")

        # 3) Quitamos los espacios antes de los ... y antes del último corchete
        usage = usage.replace(" ...] ]", "...]]")

        # 4) Tokenizamos con la nueva lógica (anidado)
        tokenized = self._tokenize_usage(usage)

        # 5) Diccionario de tokens forzados
        force_new_line_for_tokens = {
            "[-sg]": False                # Salto de línea antes, pero sigue reagrupando
            ,"[-fs <FOLDER_TO_FIX>]": False  # Va solo
            ,"[-fd ['list', 'move', 'remove'] <DUPLICATES_FOLDER> [<DUPLICATES_FOLDER>...]]": True  # Va solo
        }

        # 6) Ancho real
        max_width = getattr(self, '_width', 90)

        # 7) Reconstruimos con indentaciones
        ident_spaces = 32
        usage = self._build_lines_with_forced_tokens(
            tokenized_usage   = tokenized,
            forced_tokens     = force_new_line_for_tokens,
            width             = max_width,
            first_line_indent = '',         # Sin espacios en la primera línea
            subsequent_indent = ' ' * ident_spaces    # 32 espacios en líneas siguientes, por ejemplo
        )

        return usage

    def _format_action(self, action):
        def procesar_saltos_de_linea(text, initial_indent="", subsequent_indent=""):
            # 1. Separar en líneas
            lines = text.splitlines()
            # 2. Aplicar fill() a cada línea
            wrapped_lines = [
                 textwrap.fill(
                     line,
                     width=self._width,
                     initial_indent=initial_indent,
                     subsequent_indent=subsequent_indent
                 )
                 for line in lines
            ]
            # 3. Unirlas de nuevo con saltos de línea
            return "\n".join(wrapped_lines)

        # Encabezado del argumento
        parts = [self._format_action_invocation(action)]
        # Texto de ayuda, formateado e identado
        if action.help:
            ident_spaces = 8
            help_text = procesar_saltos_de_linea(action.help, initial_indent=" " * ident_spaces, subsequent_indent=" " * ident_spaces)
            # help_text = textwrap.fill(action.help, width=self._width, initial_indent=" " * ident_spaces, subsequent_indent=" " * ident_spaces)
            parts.append(f"\n{help_text}")  # Salto de línea adicional
            # Add EXTRA MODES: after -nl, --no-log-file argument
            if help_text.lower().find('skip saving output messages to execution log file')!=-1:
                parts.append(f"\n\n\nEXTRA MODES:\n------------\n")
                extra_description = f"Following optional arguments can be used to execute the Script in any of the usefull additionals Extra Modes included. When an Extra Mode is detected only this module will be executed (ignoring the normal steps). \nIf more than one Extra Mode is detected, only the first one will be executed.\n"
                extra_description = procesar_saltos_de_linea(extra_description)
                # extra_description = textwrap.fill(extra_description, width=self._width, initial_indent="", subsequent_indent="")
                parts.append(extra_description+'\n')

        return "".join(parts)
        
    def _format_action_invocation(self, action):
        if not action.option_strings:
            # Para argumentos posicionales
            return super()._format_action_invocation(action)
        else:
            # Combina los argumentos cortos y largos con espacio adicional si es necesario
            option_strings = []
            for opt in action.option_strings:
                # Argumento corto, agrega una coma detrás
                if opt.startswith("-") and not opt.startswith("--"):
                    if len(opt) == 4:
                        option_strings.append(f"{opt},")
                    elif len(opt) == 3:
                        option_strings.append(f"{opt}, ")
                    elif len(opt) == 2:
                        option_strings.append(f"{opt},  ")
                else:
                    option_strings.append(f"{opt}")
                    
            # Combina los argumentos cortos y largos, y agrega el parámetro si aplica
            formatted_options = " ".join(option_strings).rstrip(",")
            metavar = f" {action.metavar}" if action.metavar else ""
            return f"{formatted_options}{metavar}"
            
    def _join_parts(self, part_strings):
        # Asegura que cada argumento quede separado por un salto de línea
        return "\n".join(part for part in part_strings if part)
        